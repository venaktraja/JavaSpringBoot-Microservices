package com.ecom.product_server.controller;

import org.springframework.web.bind.annotation.RestController;

import com.ecom.product_server.entity.Product;
import com.ecom.product_server.repository.ProductRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;




@RestController
@RequestMapping("/products")
public class ProductController {

	@Autowired
	private ProductRepository productRepository;
	
	//Create a Product
	
	@PostMapping
	public Product addProduct(@RequestBody Product product) {
		
		return  productRepository.save(product);
	}
	
	//Get All Products
	@GetMapping
	public List<Product> getAllProducts(){
		
		return productRepository.findAll();
	}
	
	@GetMapping("/{productId}")
	public ResponseEntity<Product> getProductById(@PathVariable Long productId){
		
		Product product = productRepository.findById(productId)
				.orElseThrow(()-> new RuntimeException("Product Not Found with ID:"+productId));
		return ResponseEntity.ok(product);
	}
}
